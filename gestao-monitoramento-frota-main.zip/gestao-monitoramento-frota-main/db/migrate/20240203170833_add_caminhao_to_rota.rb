class AddCaminhaoToRota < ActiveRecord::Migration[7.0]
  def change
    #add_foreign_key :rota, :caminhaos, column: :caminhao_id
  end
end
